package com.example.lab_6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Cases extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cases);

    }
    public void Calculadora(View view){
        Intent i = new Intent(this, Cal.class);
        startActivity(i);
    }
    public void Lista(View view){
        Intent i = new Intent(this, List.class);
        startActivity(i);
    }
    public void Salir(View view){
        finish();
    }
}