package com.example.lab_6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class List extends AppCompatActivity {
    private ListView LV1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        LV1 = findViewById(R.id.LV);
        Button addButton = findViewById(R.id.Button);

        // Crear una lista de contactos
        java.util.List<Contact> contacts = new ArrayList<>();
        contacts.add(new Contact("John Doe", "123456789", "john@example.com"));
        // Añadir más contactos según sea necesario

        // Crear y configurar el adaptador personalizado
        CustomAdapter adapter = new CustomAdapter(this, R.layout.lists_items_contacts, contacts);
        LV1.setAdapter(adapter);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Agregar un nuevo contacto a la lista
                contacts.add(new Contact("Nuevo Contacto", "987654321", "nuevo@example.com"));
                // Notificar al adaptador que los datos han cambiado
                adapter.notifyDataSetChanged();
            }
        });
    }
    public void Salir(View view){
        finish();
    }
    }
