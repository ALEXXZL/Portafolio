package com.example.lab_6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Cal extends AppCompatActivity {
    // 0->nada; 1->suma; 2->resta; 3->mult; 4->div
    private int oper = 0;
    private double numero1 = 0;
    private TextView tv_num1;
    private TextView tv_num2;
    private Button btnIgual2,btnBorrar2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cal);
        btnIgual2 = findViewById(R.id.btnIgual);
        btnBorrar2 = findViewById(R.id.btnBorrar);
        tv_num1 = findViewById(R.id.tv_num1);
        tv_num2 = findViewById(R.id.tv_num2);

        btnIgual2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num2 = Double.parseDouble(tv_num2.getText().toString());
                double res = 0.0;
                switch (oper) {
                    case 1:
                        res = numero1 + num2;
                        break;
                    case 2:
                        res = numero1 - num2;
                        break;
                    case 3:
                        res = numero1 * num2;
                        break;
                    case 4:
                        res = numero1 / num2;
                        break;
                }
                tv_num2.setText(String.valueOf(res));
                tv_num1.setText("");
            }
        });

        btnBorrar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv_num1.setText("");
                tv_num2.setText("");
                oper = 0;
            }
        });
    }

    public void clicNumero(View v) {
        String num2 = tv_num2.getText().toString();

        int id = v.getId();

        if (id == R.id.btn0) {
            tv_num2.setText(num2 + "0");
        } else if (id == R.id.btn1) {
            tv_num2.setText(num2 + "1");
        } else if (id == R.id.btn2) {
            tv_num2.setText(num2 + "2");
        } else if (id == R.id.btn3) {
            tv_num2.setText(num2 + "3");
        } else if (id == R.id.btn4) {
            tv_num2.setText(num2 + "4");
        } else if (id == R.id.btn5) {
            tv_num2.setText(num2 + "5");
        } else if (id == R.id.btn6) {
            tv_num2.setText(num2 + "6");
        } else if (id == R.id.btn7) {
            tv_num2.setText(num2 + "7");
        } else if (id == R.id.btn8) {
            tv_num2.setText(num2 + "8");
        } else if (id == R.id.btn9) {
            tv_num2.setText(num2 + "9");
        } else if (id == R.id.btnPunto) {
            tv_num2.setText(num2 + ".");
        }
    }

    public void clicOperacion(View view) {
        String num2 = tv_num2.getText().toString();
        numero1 = Double.parseDouble(num2);
        tv_num2.setText("");

        int id = view.getId();

        if (id == R.id.btnSumar) {
            tv_num1.setText(num2 + "+");
            oper = 1;
        } else if (id == R.id.btnRestar) {
            tv_num1.setText(num2 + "-");
            oper = 2;
        } else if (id == R.id.btnMult) {
            tv_num1.setText(num2 + "*");
            oper = 3;
        } else if (id == R.id.btnDividir) {
            tv_num1.setText(num2 + "/");
            oper = 4;
        }
    }
    public void Salir(View view){
        finish();
    }
}


