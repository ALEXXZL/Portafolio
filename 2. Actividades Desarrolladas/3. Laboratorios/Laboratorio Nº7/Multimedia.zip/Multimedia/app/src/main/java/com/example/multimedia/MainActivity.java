package com.example.multimedia;

import static com.example.multimedia.R.drawable.pausar;
import static com.example.multimedia.R.drawable.reproducir;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button play_pause, btn_repetir;
    MediaPlayer mp;
    ImageView iv;
    int repetir = 2, posicion = 0;

    MediaPlayer vectormp[] = new MediaPlayer[4]; // cantidad de canciones que se van a reproducir


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        play_pause = findViewById(R.id.button4);
        btn_repetir = findViewById(R.id.button2);
        iv = findViewById(R.id.imageView);

        //posiciones de las canciones
        vectormp[0] = MediaPlayer.create(this,R.raw.mario);
        vectormp[1] = MediaPlayer.create(this,R.raw.avengers);
        vectormp[2] = MediaPlayer.create(this,R.raw.marvel);
        vectormp[3] = MediaPlayer.create(this,R.raw.champions);
    }

    //Metodo para el boton PlayPause
    public void PlayPause(View v){
        if(vectormp[posicion].isPlaying()){
            vectormp[posicion].pause();
            play_pause.setBackgroundResource(R.drawable.reproducir);
            Toast.makeText(this,"Pausa",Toast.LENGTH_SHORT).show();
        }else {
            vectormp[posicion].start();
            play_pause.setBackgroundResource(R.drawable.pausar);
            Toast.makeText(this,"Play",Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo para el boton Stop
    public void Stop(View view){
        if(vectormp[posicion] != null){
            vectormp[posicion].stop();
            vectormp[0] = MediaPlayer.create(this,R.raw.mario);
            vectormp[1] = MediaPlayer.create(this,R.raw.avengers);
            vectormp[2] = MediaPlayer.create(this,R.raw.marvel);
            vectormp[3] = MediaPlayer.create(this,R.raw.champions);

            //regresa a la posicion 0
            posicion = 0;
            play_pause.setBackgroundResource(R.drawable.reproducir);
            iv.setImageResource(R.drawable.mario_bross);
            Toast.makeText(this,"Stop",Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo repetir una pista
    public void Repetir(View v){
        if(repetir ==1){
            btn_repetir.setBackgroundResource(R.drawable.no_repetir);
            Toast.makeText(this,"No repetir",Toast.LENGTH_SHORT).show();
            vectormp[posicion].setLooping(false);
            repetir = 3;
        }else{
            btn_repetir.setBackgroundResource(R.drawable.repetir);
            Toast.makeText(this,"Repetir",Toast.LENGTH_SHORT).show();
            vectormp[posicion].setLooping(false);
            repetir = 1;
        }
    }

    //Metodo para saltar a la siguiente cancion
    public void Siguiente(View v){
        if(posicion< vectormp.length -1){
            if(vectormp[posicion].isPlaying()){
                vectormp[posicion].stop();
                posicion++;
                vectormp[posicion].start();

                if (posicion == 0) {
                    iv.setImageResource(R.drawable.mario_bross);
                } else if(posicion==1){
                    iv.setImageResource(R.drawable.avengerss);
                }else if(posicion==2){
                    iv.setImageResource(R.drawable.marvell);
                }else if(posicion==3){
                    iv.setImageResource(R.drawable.championss);
                }
            }else{
                posicion++;

                if (posicion == 0) {
                    iv.setImageResource(R.drawable.mario_bross);
                } else if(posicion==1){
                    iv.setImageResource(R.drawable.avengerss);
                }else if(posicion==2){
                    iv.setImageResource(R.drawable.marvell);
                }else if(posicion==3){
                    iv.setImageResource(R.drawable.championss);
                }
            }
        }else{
            Toast.makeText(this,"No hay mas canciones",Toast.LENGTH_SHORT).show();
        }
    }

    //Metodo para regresar a la cancion anterior
    public void Anterior(View v){
        if(posicion >=1){
            if(vectormp[posicion].isPlaying()){
                vectormp[posicion].stop();
                vectormp[0] = MediaPlayer.create(this,R.raw.mario);
                vectormp[1] = MediaPlayer.create(this,R.raw.avengers);
                vectormp[2] = MediaPlayer.create(this,R.raw.marvel);
                vectormp[3] = MediaPlayer.create(this,R.raw.champions);
                posicion--;

                if (posicion == 0) {
                    iv.setImageResource(R.drawable.mario_bross);
                } else if(posicion==1){
                    iv.setImageResource(R.drawable.avengerss);
                }else if(posicion==2){
                    iv.setImageResource(R.drawable.marvell);
                }else if(posicion==3){
                    iv.setImageResource(R.drawable.championss);
                }

                vectormp[posicion].start();
            }else{
                posicion--;

                if (posicion == 0) {
                    iv.setImageResource(R.drawable.mario_bross);
                } else if(posicion==1){
                    iv.setImageResource(R.drawable.avengerss);
                }else if(posicion==2){
                    iv.setImageResource(R.drawable.marvell);
                }else if(posicion==3){
                    iv.setImageResource(R.drawable.championss);
                }
            }
        }else{
            Toast.makeText(this,"No hay mas canciones",Toast.LENGTH_SHORT).show();
        }
    }
}